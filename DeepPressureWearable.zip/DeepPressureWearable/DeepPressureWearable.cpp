// DeepPressureWearable.cpp
// Written by: Sreela Kodali, kodali@stanford.edu

#include "Arduino.h"
#include "pins_arduino.h"
#include "DeepPressureWearable.h"


//Constructor
DeepPressureWearable::DeepPressureWearable(bool keyboard, bool serial) {

	// settings
	keyboardON = keyboard;
	serialON = serial;

	// DEFAULT Calibration settings
	user_position_MIN = POSITION_MIN;
	user_position_MAX = POSITION_MAX;
	user_flex_MIN = FLEX_MIN;
	user_flex_MAX = FLEX_MAX;

	// Linear Actuator, command, position
	Servo actuator1;
	position1_Command = 0;
	position1_Measured = 0;
	// position1_OUT = position_OUT;// PWM output pin
	// position1_IN = position_IN;// analog read in position pin
	
	cycleCount = 0; // cycleCount
	powerOn = 0; // powerOn

	// flex sensor and angle
	ADS  capacitiveFlexSensor;
	flexSensor = 0.0;

	// Pushbutton & LED
	buttonState = 0; // button state
	oldButtonState = 0; // old button state
	buttonCount = 0; // button count

	initializeSystem();
}


// Public methods
void DeepPressureWearable::testLed () {
  digitalWrite(led_OUT, HIGH);   // turn the LED on (HIGH is the voltage level)
  delay(1000);               // wait for a second
  digitalWrite(led_OUT, LOW);    // turn the LED off by making the voltage LOW
  delay(1000);               // wait for a second
}

void DeepPressureWearable::testPushbutton () {
  digitalWrite(led_OUT, LOW);
  if (risingEdgeButton()) {
    if (serialON) Serial.println("Pushed!");
    digitalWrite(led_OUT, HIGH);
    delay(50);
    digitalWrite(led_OUT, LOW);
  }
}

void DeepPressureWearable::blink_T (int t_d) {
  digitalWrite(led_OUT, LOW);
  delay(t_d);
  digitalWrite(led_OUT, HIGH);
  delay(t_d);
}

void DeepPressureWearable::safety() {
      // Safety withdraw actuator and stop
    if (risingEdgeButton()) {
      actuator1.write(position_MIN);
      if (serialON) Serial.println("Device off. Turn off power.");
      // if (sdWriteON) {
      //   File dataFile = SD.open("raw_data.csv", FILE_WRITE);
      //   if (dataFile) {
      //       //dataFile.print(buf);
      //       dataFile.close();
      //   }
      // }
      while (1);
    }
}

void DeepPressureWearable::runtime(bool feedback) {
    short data;
    unsigned long myTime;

    // time for the beginning of the loop
    myTime = millis();
    // Read flex sensor
    if (capacitiveFlexSensor.available() == true) flexSensor = abs(capacitiveFlexSensor.getX());
    //myTime_1 = micros();
    
     // Map angle to actuator command
    // if (fastMapON) position1_Command = mapper.map(flexSensor);
    // else position1_Command = map(int(flexSensor), int(user_flex_MIN), int(user_flex_MAX), user_position_MIN, user_position_MAX); // FIX: why does fastmap on and off change the outcome. And why does map not work when 0,180 vs user_MIN user MAX
    
    position1_Command = map(int(flexSensor), int(user_flex_MIN), int(user_flex_MAX), user_position_MIN, user_position_MAX);
    //FIX WHY does fast map on cause actuator to move to extremes only
    if(position1_Command > position_MAX) position1_Command = position_MAX;
    else if(position1_Command < position_MIN) position1_Command = position_MIN;

    //myTime_2 = micros(); // after computation
    
    // Send command to actuator
    if (feedback) actuator1.write(position1_Command);
    else actuator1.write(position_MIN);

    //myTime_3 = micros(); // after sending to servo
    
    // Measure actuator position
    position1_Measured = analogRead(position1_IN);

    cycleCount = cycleCount + 1;

    //myTime_4 = micros(); // after reading
    
    if ((cycleCount == WRITE_COUNT)) {
      data = readDataFromSensor(I2C_ADDR);
      powerOn = (data >= 150);
      if (powerOn) analogWrite(led_OUT, 255);
      else analogWrite(led_OUT, 30);
      //writeOutDataBatching(myTime, flexSensor, position1_Command, position1_Measured, data, myTime_1, myTime_2, myTime_3, myTime_4);
      writeOutData(myTime, flexSensor, position1_Command, position1_Measured, data);
      cycleCount = 0;
    }


    risingEdgeButton();
    if (T_CYCLE > 0) delay(T_CYCLE);    

    //myTime_5 = micros(); // after data write out
}


// Private methods 
bool DeepPressureWearable::initializeSystem() {
  Wire.begin(); // join i2c bus
  initializeSerial(); // start serial for output
  initializeActuator(); // initialize actuator and set in min position
  if (!(keyboardON)) initializeFlexSensor(); // initialize flex sensor
  else {
    WRITE_COUNT = 30;
    flexSensor = 180;
  }
  initializeIO(); // initialize IO pins, i.e. button and led
  return (true); 
}

bool DeepPressureWearable::initializeSerial() {
    Serial.begin(4608000);  
    Serial.flush();
    while (!Serial);
    return (true); 
}

bool DeepPressureWearable::initializeActuator() {
  actuator1.attach(position1_OUT); // attach servo 
  actuator1.write(position_MIN); //put in minimum position
  return (true);
}

bool DeepPressureWearable::initializeFlexSensor() {
    if (capacitiveFlexSensor.begin() == false) {
      Serial.println(("No sensor detected. Check wiring. Freezing..."));
      while (1);
  }
  capacitiveFlexSensor.enableStretching(true);
  return (true);
}

bool DeepPressureWearable::initializeIO() {
  pinMode(button_IN, INPUT); // set button and led
  pinMode(led_OUT, OUTPUT);
  return (true); 
}

bool DeepPressureWearable::risingEdgeButton() {
  buttonState = digitalRead(button_IN);
  //Serial.println(buttonState);
  if (buttonState != oldButtonState) {
    if (buttonState == HIGH) {
      buttonCount = buttonCount + 1;
      oldButtonState = buttonState;
      delay(300);
      return true;
    }
  }
  oldButtonState = buttonState; 
  return false;
}

void DeepPressureWearable::writeOutData(unsigned long t, float f, int c, int m, short d) {
  String dataString = "";
  if (serialON) {
  //if (sdWriteON || serialON) {
    dataString += (String(t) + "," + String(f) + "," + String(c) + "," \
    + String(m) + "," + String(d));
    // if (sdWriteON) {
    //   File dataFile = SD.open("raw_data.csv", FILE_WRITE);
    //   if (dataFile) {
    //     dataFile.println(dataString);
    //     dataFile.close();
    //   } else if (serialON) Serial.println("error opening datalog");
    // }
        if (serialON) Serial.println(dataString);
  }  
}

short DeepPressureWearable::readDataFromSensor(short address) {
  byte i2cPacketLength = 6;//i2c packet length. Just need 6 bytes from each slave
  byte outgoingI2CBuffer[3];//outgoing array buffer
  byte incomingI2CBuffer[6];//incoming array buffer
  bool debug;

  debug = false;

  outgoingI2CBuffer[0] = 0x01;//I2c read command
  outgoingI2CBuffer[1] = 128;//Slave data offset
  outgoingI2CBuffer[2] = i2cPacketLength;//require 6 bytes

  if (debug) Serial.println("Transmit address");  
  Wire.beginTransmission(address); // transmit to device 
  Wire.write(outgoingI2CBuffer, 3);// send out command
  if (debug) Serial.println("Check sensor status");
  byte error = Wire.endTransmission(); // stop transmitting and check slave status
  if (debug) Serial.println("bloop");
  if (error != 0) return -1; //if slave not exists or has error, return -1
  Wire.requestFrom((uint8_t)address, i2cPacketLength);//require 6 bytes from slave
  if (debug) Serial.println("Request bytes from sensor");
  
  byte incomeCount = 0;
  while (incomeCount < i2cPacketLength)    // slave may send less than requested
  {
    if (Wire.available())
    {
      incomingI2CBuffer[incomeCount] = Wire.read(); // receive a byte as character
      incomeCount++;
      if (debug) Serial.println("Read byte from sensor");
    }
    else
    {
      delayMicroseconds(10); //Wait 10us 
      if (debug) Serial.println("Waiting from sensor");
    }
  }

  short rawData = (incomingI2CBuffer[4] << 8) + incomingI2CBuffer[5]; //get the raw data

  return rawData;
}


